

<?php $__env->startSection('title', 'Shopping Cart - Exclusive Electronics Store'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 py-8">
    <!-- Breadcrumb -->
    <nav class="mb-8">
        <ol class="flex items-center space-x-2 text-sm text-gray-600">
            <li><a href="<?php echo e(route('home')); ?>" class="hover:text-red-500">Home</a></li>
            <li><i class="fas fa-chevron-right text-xs"></i></li>
            <li class="text-gray-900">Cart</li>
        </ol>
    </nav>

    <?php if($cartItems->count() > 0): ?>
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Cart Items -->
        <div class="lg:col-span-2">
            <div class="bg-white rounded-lg border">
                <div class="p-6 border-b">
                    <h1 class="text-2xl font-bold text-gray-900">Shopping Cart</h1>
                    <p class="text-gray-600 mt-1"><?php echo e($cartItems->count()); ?> items in your cart</p>
                </div>

                <div class="divide-y">
                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-6" id="cart-item-<?php echo e($item->id); ?>">
                        <div class="flex items-center space-x-4">
                            <div class="flex-shrink-0 w-24 h-24 bg-gray-100 rounded-lg overflow-hidden">
                                <?php if($item->product->primary_image): ?>
                                    <img src="<?php echo e(Storage::url($item->product->primary_image->image_path)); ?>" 
                                         alt="<?php echo e($item->product->name); ?>" 
                                         class="w-full h-full object-contain">
                                <?php else: ?>
                                    <div class="w-full h-full flex items-center justify-center">
                                        <i class="fas fa-image text-gray-400"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="flex-1">
                                <h3 class="font-semibold text-gray-900 mb-1">
                                    <a href="<?php echo e(route('products.show', $item->product->slug)); ?>" 
                                       class="hover:text-red-500"><?php echo e($item->product->name); ?></a>
                                </h3>
                                <p class="text-sm text-gray-600 mb-2">SKU: <?php echo e($item->product->sku); ?></p>
                                <p class="text-sm text-gray-600 mb-3"><?php echo e($item->product->short_description); ?></p>
                                
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center space-x-4">
                                        <div class="flex items-center border rounded">
                                            <button onclick="updateQuantity(<?php echo e($item->id); ?>, <?php echo e($item->quantity - 1); ?>)" 
                                                    class="px-3 py-1 hover:bg-gray-100 <?php echo e($item->quantity <= 1 ? 'opacity-50 cursor-not-allowed' : ''); ?>">
                                                -
                                            </button>
                                            <span class="px-3 py-1 border-x"><?php echo e($item->quantity); ?></span>
                                            <button onclick="updateQuantity(<?php echo e($item->id); ?>, <?php echo e($item->quantity + 1); ?>)" 
                                                    class="px-3 py-1 hover:bg-gray-100">
                                                +
                                            </button>
                                        </div>
                                        
                                        <button onclick="removeFromCart(<?php echo e($item->id); ?>)" 
                                                class="text-red-500 hover:text-red-700 text-sm">
                                            <i class="fas fa-trash mr-1"></i>Remove
                                        </button>
                                    </div>
                                    
                                    <div class="text-right">
                                        <p class="text-lg font-semibold text-gray-900"><?php echo e($item->formatted_total); ?></p>
                                        <?php if($item->product->compare_price && $item->product->compare_price > $item->product->price): ?>
                                        <p class="text-sm text-gray-500 line-through"><?php echo e($item->product->formatted_compare_price); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Continue Shopping -->
            <div class="mt-6">
                <a href="<?php echo e(route('products.index')); ?>" 
                   class="inline-flex items-center text-red-500 hover:text-red-600">
                    <i class="fas fa-arrow-left mr-2"></i>Continue Shopping
                </a>
            </div>
        </div>

        <!-- Order Summary -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-lg border p-6 sticky top-4">
                <h2 class="text-lg font-semibold text-gray-900 mb-4">Order Summary</h2>
                
                <div class="space-y-3 mb-4">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Subtotal (<?php echo e($cartItems->count()); ?> items)</span>
                        <span class="text-gray-900"><?php echo e($cartSummary['subtotal']); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Shipping</span>
                        <span class="text-gray-900"><?php echo e($cartSummary['shipping']); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Tax</span>
                        <span class="text-gray-900"><?php echo e($cartSummary['tax']); ?></span>
                    </div>
                    <div class="border-t pt-3">
                        <div class="flex justify-between">
                            <span class="text-lg font-semibold text-gray-900">Total</span>
                            <span class="text-lg font-semibold text-gray-900"><?php echo e($cartSummary['total']); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Discount Code -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Discount Code</label>
                    <div class="flex">
                        <input type="text" id="discount-code" 
                               placeholder="Enter discount code"
                               class="flex-1 border border-gray-300 rounded-l-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent">
                        <button onclick="applyDiscount()" 
                                class="bg-red-500 text-white px-4 py-2 rounded-r-lg hover:bg-red-600 transition-colors">
                            Apply
                        </button>
                    </div>
                </div>

                <!-- Checkout Button -->
                <button onclick="proceedToCheckout()" 
                        class="w-full bg-red-500 text-white py-3 rounded-lg hover:bg-red-600 transition-colors font-medium">
                    Proceed to Checkout
                </button>

                <!-- Payment Methods -->
                <div class="mt-4 pt-4 border-t">
                    <p class="text-sm text-gray-600 mb-2">We accept:</p>
                    <div class="flex space-x-2">
                        <img src="/images/visa.png" alt="Visa" class="h-6">
                        <img src="/images/mastercard.png" alt="Mastercard" class="h-6">
                        <img src="/images/paypal.png" alt="PayPal" class="h-6">
                        <img src="/images/gpay.png" alt="Google Pay" class="h-6">
                    </div>
                </div>

                <!-- Security Info -->
                <div class="mt-4 pt-4 border-t">
                    <div class="flex items-center space-x-2 text-sm text-gray-600">
                        <i class="fas fa-lock"></i>
                        <span>Secure SSL encrypted payment</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php else: ?>
    <!-- Empty Cart -->
    <div class="text-center py-12">
        <i class="fas fa-shopping-cart text-6xl text-gray-400 mb-4"></i>
        <h2 class="text-2xl font-bold text-gray-600 mb-2">Your cart is empty</h2>
        <p class="text-gray-500 mb-6">Looks like you haven't added any items to your cart yet.</p>
        <a href="<?php echo e(route('products.index')); ?>" 
           class="bg-red-500 text-white px-6 py-3 rounded-lg hover:bg-red-600 transition-colors">
            Start Shopping
        </a>
    </div>
    <?php endif; ?>

    <!-- Related Products -->
    <?php if($relatedProducts->count() > 0): ?>
    <section class="mt-12">
        <h2 class="text-2xl font-bold text-gray-900 mb-6">You might also like</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-lg border overflow-hidden hover:shadow-md transition-shadow group">
                <div class="relative bg-gray-100 aspect-square overflow-hidden">
                    <?php if($product->discount_percentage > 0): ?>
                    <div class="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded z-10">
                        -<?php echo e($product->discount_percentage); ?>%
                    </div>
                    <?php endif; ?>
                    
                    <div class="absolute top-2 right-2 space-y-2 z-10">
                        <button onclick="toggleWishlist(<?php echo e($product->id); ?>)" class="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow hover:bg-gray-50">
                            <i class="far fa-heart text-gray-600 hover:text-red-500"></i>
                        </button>
                    </div>
                    
                    <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="block h-full p-4">
                        <?php if($product->primary_image): ?>
                            <img src="<?php echo e(Storage::url($product->primary_image->image_path)); ?>" 
                                 alt="<?php echo e($product->name); ?>" 
                                 class="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300">
                        <?php else: ?>
                            <div class="w-full h-full flex items-center justify-center">
                                <i class="fas fa-image text-4xl text-gray-400"></i>
                            </div>
                        <?php endif; ?>
                    </a>
                    
                    <button onclick="addToCart(<?php echo e($product->id); ?>)" 
                            class="absolute bottom-0 left-0 right-0 bg-black text-white py-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        Add to Cart
                    </button>
                </div>
                
                <div class="p-4">
                    <h3 class="font-medium mb-2 line-clamp-2">
                        <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="hover:text-red-500"><?php echo e($product->name); ?></a>
                    </h3>
                    <div class="flex items-center space-x-2">
                        <span class="text-red-500 font-semibold"><?php echo e($product->formatted_price); ?></span>
                        <?php if($product->compare_price && $product->compare_price > $product->price): ?>
                            <span class="text-gray-500 line-through text-sm"><?php echo e($product->formatted_compare_price); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function updateQuantity(itemId, newQuantity) {
    if (newQuantity < 1) return;
    
    fetch(`/cart/update/${itemId}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify({ quantity: newQuantity })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            showNotification(data.message || 'Error updating quantity', 'error');
        }
    })
    .catch(error => {
        showNotification('Error updating quantity', 'error');
    });
}

function removeFromCart(itemId) {
    if (confirm('Are you sure you want to remove this item from your cart?')) {
        fetch(`/cart/remove/${itemId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById(`cart-item-${itemId}`).remove();
                showNotification('Item removed from cart', 'success');
                // Reload to update totals
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification(data.message || 'Error removing item', 'error');
            }
        })
        .catch(error => {
            showNotification('Error removing item', 'error');
        });
    }
}

function applyDiscount() {
    const discountCode = document.getElementById('discount-code').value.trim();
    
    if (!discountCode) {
        showNotification('Please enter a discount code', 'error');
        return;
    }
    
    fetch('/cart/apply-discount', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify({ code: discountCode })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Discount applied successfully!', 'success');
            location.reload();
        } else {
            showNotification(data.message || 'Invalid discount code', 'error');
        }
    })
    .catch(error => {
        showNotification('Error applying discount', 'error');
    });
}

function proceedToCheckout() {
    window.location.href = '/checkout';
}

function addToCart(productId) {
    fetch(`/cart/add/${productId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify({ quantity: 1 })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Product added to cart!', 'success');
        } else {
            showNotification(data.message || 'Error adding product to cart', 'error');
        }
    })
    .catch(error => {
        showNotification('Error adding product to cart', 'error');
    });
}

function toggleWishlist(productId) {
    fetch(`/wishlist/toggle/${productId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification(data.added ? 'Added to wishlist!' : 'Removed from wishlist!', 'success');
        }
    })
    .catch(error => {
        showNotification('Please login to add to wishlist', 'error');
    });
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg text-white ${type === 'success' ? 'bg-green-500' : 'bg-red-500'} transition-all duration-300 transform translate-x-full`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.aspect-square {
    aspect-ratio: 1 / 1;
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\e-commerce-electronic\resources\views/cart/index.blade.php ENDPATH**/ ?>