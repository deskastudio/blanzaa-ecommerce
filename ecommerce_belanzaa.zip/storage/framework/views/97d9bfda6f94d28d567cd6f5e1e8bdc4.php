

<?php $__env->startSection('title', 'Sign Up - Exclusive'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-white">
    <div class="grid grid-cols-1 lg:grid-cols-2 min-h-screen">
        <!-- Left Side - Image -->
        <div class="hidden lg:block bg-blue-50 relative">
            <div class="absolute inset-0 flex items-center justify-center p-8">
                <div class="max-w-md">
                    <!-- Shopping Cart and Phone Illustration -->
                    <div class="relative">
                        <!-- Shopping Cart -->
                        <div class="w-32 h-24 bg-gray-300 rounded-lg mb-4 mx-auto relative">
                            <div class="absolute -bottom-2 -left-2 w-6 h-6 bg-gray-400 rounded-full"></div>
                            <div class="absolute -bottom-2 -right-2 w-6 h-6 bg-gray-400 rounded-full"></div>
                            <div class="absolute top-2 left-2 right-2 h-4 bg-gray-400 rounded"></div>
                        </div>
                        
                        <!-- Phone -->
                        <div class="w-20 h-36 bg-gray-800 rounded-xl mx-auto relative">
                            <div class="absolute top-2 left-2 right-2 bottom-6 bg-gray-200 rounded-lg"></div>
                            <div class="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-8 h-1 bg-gray-600 rounded-full"></div>
                        </div>
                        
                        <!-- Shopping Bags -->
                        <div class="absolute -right-4 top-8 w-12 h-16 bg-pink-300 rounded-lg"></div>
                        <div class="absolute -right-8 top-12 w-10 h-14 bg-pink-400 rounded-lg"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side - Register Form -->
        <div class="flex items-center justify-center p-8">
            <div class="w-full max-w-md">
                <div class="mb-8">
                    <h1 class="text-3xl font-medium text-gray-900 mb-2">Create an account</h1>
                    <p class="text-gray-600">Enter your details below</p>
                </div>

                <form method="POST" action="<?php echo e(route('register')); ?>" class="space-y-6">
                    <?php echo csrf_field(); ?>
                    
                    <!-- Name Field -->
                    <div>
                        <input type="text" 
                               name="name" 
                               value="<?php echo e(old('name')); ?>"
                               placeholder="Name"
                               required
                               class="w-full px-0 py-3 border-0 border-b border-gray-300 focus:border-red-500 focus:outline-none focus:ring-0 bg-transparent placeholder-gray-500">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Email Field -->
                    <div>
                        <input type="email" 
                               name="email" 
                               value="<?php echo e(old('email')); ?>"
                               placeholder="Email or Phone Number"
                               required
                               class="w-full px-0 py-3 border-0 border-b border-gray-300 focus:border-red-500 focus:outline-none focus:ring-0 bg-transparent placeholder-gray-500">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Phone Field -->
                    <div>
                        <input type="text" 
                               name="phone" 
                               value="<?php echo e(old('phone')); ?>"
                               placeholder="Phone Number (Optional)"
                               class="w-full px-0 py-3 border-0 border-b border-gray-300 focus:border-red-500 focus:outline-none focus:ring-0 bg-transparent placeholder-gray-500">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Password Field -->
                    <div>
                        <input type="password" 
                               name="password"
                               placeholder="Password"
                               required
                               class="w-full px-0 py-3 border-0 border-b border-gray-300 focus:border-red-500 focus:outline-none focus:ring-0 bg-transparent placeholder-gray-500">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Confirm Password Field -->
                    <div>
                        <input type="password" 
                               name="password_confirmation"
                               placeholder="Confirm Password"
                               required
                               class="w-full px-0 py-3 border-0 border-b border-gray-300 focus:border-red-500 focus:outline-none focus:ring-0 bg-transparent placeholder-gray-500">
                    </div>

                    <!-- Create Account Button -->
                    <div class="pt-4">
                        <button type="submit" 
                                class="w-full bg-red-500 hover:bg-red-600 text-white font-medium py-3 px-8 rounded transition-colors">
                            Create Account
                        </button>
                    </div>
                </form>

                <!-- Log In Link -->
                <div class="mt-8 text-center">
                    <p class="text-gray-600">
                        Already have account? 
                        <a href="<?php echo e(route('login')); ?>" class="text-red-500 hover:text-red-600 font-medium">
                            Log in
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* Custom styles for border-bottom inputs */
.focus\:border-red-500:focus {
    border-bottom-color: #ef4444 !important;
    box-shadow: 0 1px 0 0 #ef4444;
}

/* Remove default input styling */
input[type="text"]:focus,
input[type="email"]:focus,
input[type="password"]:focus {
    outline: none;
    box-shadow: none;
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\e-commerce-electronic\resources\views/auth/register.blade.php ENDPATH**/ ?>